import java.awt.Image;
import java.awt.Graphics;

public class Coin {
	
	private Image hi, ho;
	private int side=1;
	
	public Coin(Image x, Image y){
		hi = x;
		ho = y;
	}
	
	public void flip(){
		if(side == 1)
			side = 0;
		else
			side = 1;
	}
	
	public void draw(Graphics g, int x, int y){
		if(side==1)
			g.drawImage(hi, x, y, null);
		else
			g.drawImage(ho, x, y, null);
	}
}

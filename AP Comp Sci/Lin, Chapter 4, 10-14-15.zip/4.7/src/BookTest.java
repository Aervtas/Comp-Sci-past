
public class BookTest {

	public static void main(String[] args) {
		Book satPrep = new Book(3);
		satPrep.nextPage();
		System.out.println("You are on page "+satPrep.getCurrent());
		satPrep.nextPage();
		System.out.println("You are on page "+satPrep.getCurrent());
		satPrep.nextPage();
		System.out.println("You are on page "+satPrep.getCurrent());
	}

}

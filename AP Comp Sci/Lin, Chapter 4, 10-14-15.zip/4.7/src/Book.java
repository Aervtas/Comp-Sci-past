
public class Book {
	
	private int numPages, currentPage;
	
	public Book(int x){
		numPages = x;
		currentPage = 1;
	}
	
	public int getPages(){
		return numPages;
	}
	
	public int getCurrent(){
		return currentPage;
	}
	
	public void nextPage(){
		if(currentPage < numPages)
			currentPage++;
		else
			System.out.println("This is the last page");
	}
}

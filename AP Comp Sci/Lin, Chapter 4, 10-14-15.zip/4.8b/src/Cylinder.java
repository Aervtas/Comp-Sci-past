
public class Cylinder {
	
	double height;
	Circle base;
	
	public Cylinder(int r, int h){
		base = new Circle(r);
		height = h;
	}
	
	public double getVolume(){
		return base.getArea()*height;
	}

}

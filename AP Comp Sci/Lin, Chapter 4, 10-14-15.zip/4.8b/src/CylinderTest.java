import java.util.Scanner;

public class CylinderTest {

	public static void main(String[] args) {
		int r, h;
		Scanner sc = new Scanner(System.in);
		Cylinder cola;
		
		System.out.println("Enter the radius and height of a cylinder.");
		System.out.print("Radius: ");
		r = sc.nextInt();
		System.out.print("Height: ");
		h = sc.nextInt();
		cola = new Cylinder(r, h);
		System.out.println("The volume of the cylinder is "+cola.getVolume());
	}

}

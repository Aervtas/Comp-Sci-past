import java.util.Scanner;

public class CircleTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n;
		Circle friendlyName;
		System.out.print("Please enter the integer for the radius a circle: ");
		n = sc.nextInt();
		friendlyName = new Circle(n);
		System.out.println("The area is "+friendlyName.getArea());
	}

}

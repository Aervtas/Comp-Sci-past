import java.awt.Color;

public class SquareBalloon extends Balloon{
	
	public SquareBalloon(){}
	
	public SquareBalloon(int x, int y, int r, Color c){
		super(x, y, r, c);
	}
}

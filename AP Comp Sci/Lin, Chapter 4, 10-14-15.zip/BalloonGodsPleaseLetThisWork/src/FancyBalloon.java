import java.awt.Color;

public class FancyBalloon extends Balloon{
	
	public FancyBalloon(){}
	
	public FancyBalloon(int x, int y, int r, Color c){
		super(x, y, r, c);
	}
}

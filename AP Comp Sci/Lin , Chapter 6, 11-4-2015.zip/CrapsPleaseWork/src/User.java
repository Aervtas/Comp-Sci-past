
public class User {

	public static void main(String[] args) {
		Die die = new Die();
		die.roll();
		System.out.println(die.getNumDots());
		die.roll();
		System.out.println(die.getNumDots());
		die.roll();
		System.out.println(die.getNumDots());
		die.roll();
		System.out.println(die.getNumDots());
		die.roll();
		System.out.println(die.getNumDots());
	}

}

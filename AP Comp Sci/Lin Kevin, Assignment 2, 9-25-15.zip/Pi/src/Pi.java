/*************************************
Student name: Kevin Lin         Period: 9
Course: AP Java Computer Programming
Teacher: Mrs. Snelson  
Date completed:     9-25-15
**************************************/
public class Pi {
	public static void main(String [] args){
		System.out.println("   #####");
		System.out.println("  #     #");
		System.out.println("((  0 0  ))");
		System.out.println("  |  V  |");
		System.out.println("  | === |");
		System.out.println("   _____");
		
	}
}

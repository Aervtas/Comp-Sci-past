/*************************************
Student name: Kevin Lin         Period: 9
Course: AP Java Computer Programming
Teacher: Mrs. Snelson  
Date completed:     9-25-15
**************************************/
public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Favorite crap = new Favorite();
		
		crap.question();
		crap.set();
		crap.end();
	}

}

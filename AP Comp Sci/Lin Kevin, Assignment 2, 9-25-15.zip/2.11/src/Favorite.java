import java.util.Scanner;
public class Favorite {
	String s;
	Scanner sc = new Scanner(System.in);
	public void question(){
		System.out.println("What is your favorite game?");
	}
	
	public void set(){
		System.out.print("> ");
		s = sc.nextLine();
	}
	
	public void end(){
		System.out.println("I think "+s+" is an okay game.");
		System.out.println("Just kidding! It's terrible get out of here.");
	}
}

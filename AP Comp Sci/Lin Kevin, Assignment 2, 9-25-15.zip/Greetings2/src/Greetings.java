/*************************************
Student name: Kevin Lin         Period: 9
Course: AP Java Computer Programming
Teacher: Mrs. Snelson  
Date completed:     9-25-15
**************************************/
import java.util.Scanner;
public class Greetings {
	public static void main(String [] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("First Name: ");
		String fname = sc.nextLine();
		System.out.print("Last Name: ");
		String lname = sc.nextLine();
		System.out.println("Hello, "+fname+" "+lname);
		System.out.println("Congratulations on you second program!");
	}
}

/*************************************
Student name: Kevin Lin         Period: 9
Course: AP Java Computer Programming
Teacher: Mrs. Snelson  
Date completed:     9-25-15
**************************************/
import java.util.Scanner;
public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Mult2 kevin = new Mult2();
		System.out.print("Enter an integer: ");
		kevin.enter(sc.nextInt());
		kevin.display(); 				//If you take out the parentheses the integers with placed next to each other instead of being added.
	}

}

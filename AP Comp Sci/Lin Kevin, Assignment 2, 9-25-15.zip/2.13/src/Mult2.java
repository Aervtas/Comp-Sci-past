
public class Mult2 {
	private int i;
	public void enter(int j){
		i = j;
	}
	public void display(){
		System.out.println("2 * "+i+" = "+(i+i));
	}
}

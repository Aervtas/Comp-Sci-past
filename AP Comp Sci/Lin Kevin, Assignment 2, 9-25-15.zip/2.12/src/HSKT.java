
public class HSKT {
	public void p1(){
		System.out.println("Head, shoulders, knees, and toes, knees, and toes,");
	}
	public void p2(){
		System.out.println("And eyes, and ears, and mouth, and nose,");
	}
	public void p3(){
		System.out.println("Head, shoulders, knees, and toes, knees, and toes.");
	}
}

/*************************************
Student name: Kevin Lin         Period: 9
Course: AP Java Computer Programming
Teacher: Mrs. Snelson  
Date completed:     9-25-15
**************************************/
public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HSKT kevin = new HSKT();
		for(int i=1; i<5; i++){
			if(i==3)
					kevin.p2();
			if(i==4)
				kevin.p3();
			if(i<3)
				kevin.p1();
		}
	}

}

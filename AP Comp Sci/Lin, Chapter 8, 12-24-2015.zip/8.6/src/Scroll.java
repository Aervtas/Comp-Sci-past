
public class Scroll {
	public String doIt(String s){
		return s.substring(1)+s.substring(0, 1);
	}
}

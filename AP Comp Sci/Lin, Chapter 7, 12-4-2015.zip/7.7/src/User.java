
public class User {

	public static void main(String[] args) {
		iDontRead hoi = new iDontRead();
		
		hoi.letsRead();
		System.out.println("It will take me "+hoi.year+" years and "+hoi.month+" month(s) to get a 95.");
		
	}

}

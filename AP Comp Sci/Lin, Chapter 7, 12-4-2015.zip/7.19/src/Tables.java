
public class Tables {
	public void multTable(int x){
		int y[]={1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
		
		for(int i=0;i<12;i++){
			System.out.print("\t"+y[i]*x);
		}
		System.out.print("\n");
	}
}

import java.util.Scanner;
public class User {

	public static void main(String[] args) {
		TwinPrimes hoi = new TwinPrimes();
		System.out.println("The first 20 pairs of twin primes are:");
		hoi.printPrime();
	}

}

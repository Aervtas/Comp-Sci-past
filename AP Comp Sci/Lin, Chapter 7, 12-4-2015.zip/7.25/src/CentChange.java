
public class CentChange {
	public void hello(int c){
		int q, d, n, p;
		
		p = c%5;					//I don't know what I am suppose to do to get all the possible representations.
		n = c%10 - p;
		d = c%25 - n - p;
		q = c - d - n - p;
		
		System.out.println(c+" cents = "+q+" quarters "+d+" dimes "+n+" nickels "+p+" pennies");
	}
}

import java.util.Scanner;
public class EstimatePi {

	/**
	 * This program is to get closer and closer to the value
	 * of pi the higher n becomes.
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double p;
		int h;
		Scanner sc = new Scanner(System.in);
		PiSolver hey = new PiSolver();
		System.out.print("Enter an Integer: ");
		h = sc.nextInt();
		p = hey.estimatePi(h);
		System.out.println("Pi estimate for n = "+h+" is "+p);
	}

}


public class PiSolver {
	private double sq, pi, sum;
	/**
	 * This method is the actual math behind estimating pi.
	 * The method involved adding 1 to 1 over 2 and then 3
	 * and so on until you get to n.
	 */
	public double estimatePi(int i){
		for(int k=1; k<=i; k++){
			sq = k*k;
			sum += 1/sq;
		}
		pi = Math.sqrt(6*sum);
		return pi;
	}
}

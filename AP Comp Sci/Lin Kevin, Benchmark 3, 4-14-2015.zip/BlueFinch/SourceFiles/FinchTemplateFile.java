 
// Needs a package declaration to move to another folder
import java.lang.String;
import edu.cmu.ri.createlab.terk.robot.finch.Finch;

/**
 * Created by: Kevin Lin
 * Date:
 * 
 */

public class FinchTemplateFile
   {
   public static void main(final String[] args)
      {
      // Instantiating the Finch object
      Finch myFinch = new Finch();
      
      // Write some code here!
      for(int i=3; i > 1; i--){                         //loop 3 times of finch running around in a circle
          myFinch.saySomething("I'm over here!");
          myFinch.setLED(255, 0, 0);
          myFinch.setWheelVelocities(255, -255, 2000);
          myFinch.setLED(0, 255, 0);
          myFinch.setWheelVelocities(-255, 255, 2000);
          myFinch.setLED(0, 0, 255);
        }
     
      myFinch.setWheelVelocities(100, 100, 3000);
      myFinch.stopWheels();
      myFinch.setLED(50, 50, 100, 1000);
      myFinch.saySomething("Thanks for picking me up.");                    //finch is rescued
      myFinch.setLED(50, 50, 100, 1000);
      myFinch.saySomething("It is finally over. I get to go home now.");
        
      while(myFinch.isLeftLightSensor(30) && myFinch.isRightLightSensor(30)){               //a lower number is equal to less light, so have the while check for the light source to disappear
        myFinch.setLED(0, 255, 0);
        }
        myFinch.setLED(255, 0, 0, 1000);
        myFinch.saySomething("Wait a second, What are you doing, Let me go!");              //plot twist, finch is captured
        myFinch.setLED(255, 0, 0, 1000);
      // Always end your program with finch.quit()
      myFinch.quit();
      System.exit(0);
      }
   }

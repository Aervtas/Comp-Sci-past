
public interface VehicleInfo {
	String VehicleType();
	int MaxPassengers();
	int MaxSpeed();
	double MilesPerGallon();
	int FuelCapacity();
}

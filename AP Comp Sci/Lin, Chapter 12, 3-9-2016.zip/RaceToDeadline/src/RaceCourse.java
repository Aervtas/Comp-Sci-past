
public interface RaceCourse {
	double Distance();
	String StartCity();
	String FinishCity();
	double FuelPrice();
}


public class Location {
	
	private int distance, r, c;
	
	public Location(int row, int col){
		r = row;
		c = col;
	}
	
	public int getRow(){
		return r;
	}
	
	public int getCol(){
		return c;
	}
	
}
